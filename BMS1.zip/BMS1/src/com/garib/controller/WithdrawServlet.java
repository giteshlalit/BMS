package com.garib.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.garib.bean.Customer;
import com.garib.service.AccountServiceImpl;

/**
 * Servlet implementation class WithdrawServlet
 */
@WebServlet("/WithdrawServlet")
public class WithdrawServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AccountServiceImpl as= new AccountServiceImpl();
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String amount=request.getParameter("amount");
		System.out.println(amount);
		Double amt=Double.valueOf(amount);
		
		
		
		HttpSession ses=request.getSession();
		String temp;
		Customer c=(Customer)ses.getAttribute("Result");
		System.out.println(c.getAccName());
		String accNo=c.getAccount().getAccNo();
		double balance=as.showBalance(accNo);
		if(balance>=amt) {
		temp=as.withdraw(accNo, amt);
//request.setAttribute("Result", c);
		double bal=as.showBalance(accNo);
		c.getAccount().setCurBal(bal);
		

		}
		else
		{
			temp="Balance Not Available";
			
		}
			System.out.println(c.getAccount().getCurBal());
		ses.setAttribute("Result", c);
		  ses.setAttribute("Value", temp); 
		  RequestDispatcher dis=request.getRequestDispatcher("Withdraw.jsp");
		  dis.forward(request, response);
		   

		  
		  
		/*
		 * } else { ses.setAttribute("Result","Invalid");
		 * //request.setAttribute("Result", "Invalid data"); RequestDispatcher
		 * dis=request.getRequestDispatcher("Login.jsp"); dis.forward(request,
		 * response); } } }
		 */

}

}

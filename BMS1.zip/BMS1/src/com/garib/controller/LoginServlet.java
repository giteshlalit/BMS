package com.garib.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.garib.bean.Account;
import com.garib.bean.Customer;
import com.garib.service.AccountServiceImpl;


 @WebServlet("/LoginServlet") 
public class LoginServlet extends HttpServlet {
		private static final long serialVersionUID = 1L;
	AccountServiceImpl as= new AccountServiceImpl();


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		HttpSession ses=request.getSession();
		
	
		
		Customer c=as.validateUser(username, password);
		PrintWriter out=response.getWriter();
		out.println(c);
		if(c!=null)
		{
			ses.setAttribute("Result", c);
			//request.setAttribute("Result", c);
			RequestDispatcher dis=request.getRequestDispatcher("Dashboard.jsp");
			dis.forward(request, response);
			
			

		}
		else
		{
			ses.setAttribute("Result","Invalid");
			//request.setAttribute("Result", "Invalid data");
			RequestDispatcher dis=request.getRequestDispatcher("Login.jsp");
			dis.forward(request, response);
		}
	}
	}



package com.garib.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.garib.bean.Account;
import com.garib.bean.Customer;
import com.garib.service.AccountServiceImpl;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AccountServiceImpl as= new AccountServiceImpl();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("hello");
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String dob=request.getParameter("dob");
		System.out.println(dob);
		String ifsc=request.getParameter("ifsc");
		String password=request.getParameter("password");
		String accType=request.getParameter("accType");
		String mobile=request.getParameter("mobile");
		String address=request.getParameter("address");
		String aadhar=request.getParameter("aadhar");
		
		Account acc =new Account(accType, 0, ifsc, password);
		Customer c=new Customer(name, dob, address, mobile, email, aadhar, acc);
		String result=as.createAccount(c);
		HttpSession ses=request.getSession();
		if(result.contains("Account Created"))
		{
			ses.setAttribute("Result", c);
			//request.setAttribute("Result", c);
			RequestDispatcher dis=request.getRequestDispatcher("Success.jsp");
			dis.forward(request, response);
			
			

		}
		else
		{
			ses.setAttribute("Answer",result);
			//request.setAttribute("Result", "Invalid data");
			RequestDispatcher dis=request.getRequestDispatcher("Register.html");
			dis.forward(request, response);
		}
	}

}

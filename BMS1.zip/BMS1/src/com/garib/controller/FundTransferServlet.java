package com.garib.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.garib.bean.Account;
import com.garib.bean.Customer;
import com.garib.service.AccountServiceImpl;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/FundTransferServlet")
public class FundTransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AccountServiceImpl as= new AccountServiceImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String amount=request.getParameter("amount");
		String recp=request.getParameter("recpAcc");
		System.out.println(amount);
		Double amt=Double.valueOf(amount);
		Account a=as.validateUser(recp);
		HttpSession ses=request.getSession();
		Customer c=(Customer)ses.getAttribute("Result");
		System.out.println(c.getAccName());
		String accNo=c.getAccount().getAccNo();
		String result;
		
		
		
		if(a!=null)
		{
			result=as.fundTransfer(accNo, recp, amt);
		}
		else
		{
			result="Transfer Declined due to invalid Recpt A/c No";
		}	
		double bal=as.showBalance(accNo);
		c.getAccount().setCurBal(bal);
			
			ses.setAttribute("Result", c);
		  ses.setAttribute("Transfer", result); 
		  RequestDispatcher dis=request.getRequestDispatcher("Fund.jsp");
		  dis.forward(request, response);
		
	}

}

package com.garib.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.garib.bean.Account;
import com.garib.bean.Customer;
import com.garib.bean.Transaction;
import com.garib.service.AccountServiceImpl;


/**
 * Servlet implementation class TransactionServlet
 */
@WebServlet("/TransactionServlet")
public class TransactionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AccountServiceImpl as= new AccountServiceImpl();

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession ses=request.getSession();
		Customer c=(Customer)ses.getAttribute("Result");
		System.out.println(c.getAccName());
		String accNo=c.getAccount().getAccNo();
		
		
		List<Transaction> li2=new ArrayList<Transaction>();
		li2=as.printTransaction(accNo);
		
	
	
		ses.setAttribute("list", li2);
		
		RequestDispatcher dis=request.getRequestDispatcher("Transaction.jsp");
		dis.forward(request, response);
	}

}
